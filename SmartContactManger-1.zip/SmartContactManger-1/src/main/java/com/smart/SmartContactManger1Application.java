package com.smart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartContactManger1Application {

	public static void main(String[] args) {
		SpringApplication.run(SmartContactManger1Application.class, args);
	}

}
