package com.smart.helper;

public class MessageHelp {

	private String content;
	private String type;
	public MessageHelp() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MessageHelp(String content, String type) {
		super();
		this.content = content;
		this.type = type;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}