package com.smart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartContactManger1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
